"""Student OS backend package."""

__version__ = "0.18.0"
